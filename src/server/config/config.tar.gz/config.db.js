var mysql = require('mysql');
exports.connection = mysql.createConnection({
    host: '127.0.0.1',
    user: 'osotemi_web',
    password: '0r3t0_mysql',
    database: 'oFindmenu'
});
